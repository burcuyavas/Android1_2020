package com.serifgungor.aracilanlari.Model;

import java.io.Serializable;

public class Marka implements Serializable {
    //POJO CLASS - Model
    private int id;
    private String markaAdi;
    private String logo;

    public Marka() {
    }

    public Marka(int id, String markaAdi, String logo) {
        this.id = id;
        this.markaAdi = markaAdi;
        this.logo = logo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarkaAdi() {
        return markaAdi;
    }

    public void setMarkaAdi(String markaAdi) {
        this.markaAdi = markaAdi;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    /*
        KAPSÜLLEME İŞLEMİ
        1. AŞAMA - Değişkenlerin private erişim seviyesinde tanımlanması
        2. AŞAMA - Sınıf ismiyle aynı isimde boş ve dolu constuctorlar üretilmesi.
        3. AŞAMA - Her bir değişken için get ve set metotların oluşturulması

   Intent'in put extra metodu sayesinde 2. argüman olarak basit veri tiplerini diğer sayfaya taşıyabiliriz.

   Eğer basit veri tipi değil de, referans veri tipini intent ile taşımak istiyorsak ilgili sınıfın
   Serializable interface'inden türemesi gerekmektedir.
     */

}
