package com.serifgungor.aracilanlari.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.aracilanlari.Model.Marka;
import com.serifgungor.aracilanlari.R;

import java.util.ArrayList;

public class AdapterMarka extends BaseAdapter {

    private ArrayList<Marka> markalar;
    private Context context;
    private LayoutInflater layoutInflater;


    public AdapterMarka(){
    }

    public AdapterMarka(Context context,ArrayList<Marka> markalar){
        this.context = context;
        this.markalar = markalar;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        /*
        Layout Inflater yapısı sayesinde adapter nesnesinin her satırını bir layout formatında gösterebiliriz.

        Bağlayıcı görevi üstlenen LayoutInflater yapısı, geri dönüş tipi View olan getView metodu içerisinde
        belirtilen tipte layout sayfasını gösterebilmek için kullanılır.
         */
    }

    @Override
    public int getCount() {
        return markalar.size();
    }
    @Override
    public Object getItem(int position) {
        return markalar.get(position);
    }
    @Override
    public long getItemId(int position) {
        return markalar.get(position).getId();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = layoutInflater.inflate(R.layout.marka_satirgoruntusu,null);
        ImageView ivLogo = view.findViewById(R.id.ivMarkaLogo);
        TextView tvBaslik = view.findViewById(R.id.tvMarkaBaslik);
        tvBaslik.setText(markalar.get(position).getMarkaAdi());
        int resId = view.getResources().getIdentifier(
                markalar.get(position).getLogo(),
                "drawable",
                context.getPackageName()
        );
        ivLogo.setImageResource(resId);
        /*
        getResources().getIdentifier() ile sağlanan kolaylık
        Belirtilen uygulama paketinin içerisindeki drawable klasörü içerisinde bir dosya ismini belirtip
        o dosyanın referans id'sini int olarak elde etmek istiyorsak Identifier kavramına ihtiyaç duyarız.
         */
        return view;
    }

    /*
    getCount - Arraylist'in eleman sayısını döner
    getItem - Arraylist'in ilgili indexinde bulunan item'i getirir.
    getItemId - Eğer varsa item'a ait id'yi getirir.
    getView
    - Adapter'ın üretilen satır görüntüsüne bağlanması işlemini sağlar.
    - Arraylistin ilgili elemanına ait değerleri ilgili satır görüntüsündeki nesnelerin değerleriyle değiştirilme
    işlemini de sağlar.


     */

}
