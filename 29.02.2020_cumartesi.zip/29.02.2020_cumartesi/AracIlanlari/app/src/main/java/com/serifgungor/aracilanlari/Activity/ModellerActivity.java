package com.serifgungor.aracilanlari.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.aracilanlari.Adapter.AdapterAracModeli;
import com.serifgungor.aracilanlari.Model.AracModeli;
import com.serifgungor.aracilanlari.Model.Marka;
import com.serifgungor.aracilanlari.R;

import java.util.ArrayList;

public class ModellerActivity extends AppCompatActivity {

    ArrayList<AracModeli> aracModelleri = new ArrayList<>();
    AdapterAracModeli adapterAracModeli;
    ListView listView;
    Marka marka;


    public void listeyiDoldur(){
        for (int i=0; i<20; i++){
            //int modelId, int markaId, String modelAdi, String modelResim, int ilkUretimYili, int sonUretimYili
            aracModelleri.add(new AracModeli(i,marka.getId(),"Model "+i,marka.getLogo(),2000,2020));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modeller);

        marka = (Marka) getIntent().getSerializableExtra("marka");
        this.setTitle(marka.getMarkaAdi());

        listView = findViewById(R.id.listViewModeller);
        listeyiDoldur();


        adapterAracModeli = new AdapterAracModeli(getApplicationContext(),aracModelleri);
        listView.setAdapter(adapterAracModeli);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),AraclarActivity.class);
                intent.putExtra("model",aracModelleri.get(position));
                startActivity(intent);
            }
        });
    }
}
