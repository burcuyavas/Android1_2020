package com.serifgungor.aracilanlari.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import com.serifgungor.aracilanlari.Adapter.AdapterMarka;
import com.serifgungor.aracilanlari.Model.Marka;
import com.serifgungor.aracilanlari.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    ArrayList<Marka> markalar;
    AdapterMarka adapterMarka;

    public void listeyiDoldur(){
        //int id, String markaAdi, String logo
        markalar.add(new Marka(1,"Mercedes","mercedes"));
        markalar.add(new Marka(2,"BMW","bmw"));
        markalar.add(new Marka(3,"Audi","audi"));
        markalar.add(new Marka(4,"Porsche","porsche"));
        markalar.add(new Marka(5,"Citroen","citroen"));
        markalar.add(new Marka(6,"Fiat","fiat"));
        markalar.add(new Marka(7,"Volkswagen","vw"));
        markalar.add(new Marka(8,"Renault","renault"));
        markalar.add(new Marka(9,"Peugeot","peugeot"));
        markalar.add(new Marka(10,"Ferrari","ferrari"));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridViewMarkalar);
        markalar = new ArrayList<>();
        listeyiDoldur();
        adapterMarka = new AdapterMarka(getApplicationContext(),markalar);
        gridView.setAdapter(adapterMarka);


        this.setTitle("Araç Markaları");

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(),ModellerActivity.class);
                intent.putExtra("marka",markalar.get(position));
                startActivity(intent);

            }
        });

    }
}
