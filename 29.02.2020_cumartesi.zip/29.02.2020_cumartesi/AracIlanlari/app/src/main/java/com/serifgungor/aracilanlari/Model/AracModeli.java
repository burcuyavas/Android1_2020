package com.serifgungor.aracilanlari.Model;

import java.io.Serializable;

public class AracModeli implements Serializable {
    private int modelId;
    private int markaId;
    private String modelAdi;
    private String modelResim;
    private int ilkUretimYili;
    private int sonUretimYili;


    public AracModeli() {
    }

    public AracModeli(int modelId, int markaId, String modelAdi, String modelResim, int ilkUretimYili, int sonUretimYili) {
        this.modelId = modelId;
        this.markaId = markaId;
        this.modelAdi = modelAdi;
        this.modelResim = modelResim;
        this.ilkUretimYili = ilkUretimYili;
        this.sonUretimYili = sonUretimYili;
    }

    public int getModelId() {
        return modelId;
    }

    public void setModelId(int modelId) {
        this.modelId = modelId;
    }

    public int getMarkaId() {
        return markaId;
    }

    public void setMarkaId(int markaId) {
        this.markaId = markaId;
    }

    public String getModelAdi() {
        return modelAdi;
    }

    public void setModelAdi(String modelAdi) {
        this.modelAdi = modelAdi;
    }

    public String getModelResim() {
        return modelResim;
    }

    public void setModelResim(String modelResim) {
        this.modelResim = modelResim;
    }

    public int getIlkUretimYili() {
        return ilkUretimYili;
    }

    public void setIlkUretimYili(int ilkUretimYili) {
        this.ilkUretimYili = ilkUretimYili;
    }

    public int getSonUretimYili() {
        return sonUretimYili;
    }

    public void setSonUretimYili(int sonUretimYili) {
        this.sonUretimYili = sonUretimYili;
    }
}
