package com.serifgungor.aracilanlari.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.aracilanlari.R;

public class AraclarActivity extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_araclar);

        listView = findViewById(R.id.listViewAraclar);
    }
}
