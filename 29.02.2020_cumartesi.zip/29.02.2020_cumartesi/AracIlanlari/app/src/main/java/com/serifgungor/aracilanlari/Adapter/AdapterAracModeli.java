package com.serifgungor.aracilanlari.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.aracilanlari.Model.AracModeli;
import com.serifgungor.aracilanlari.R;

import java.util.ArrayList;

public class AdapterAracModeli extends BaseAdapter {

    private ArrayList<AracModeli> aracModelleri;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterAracModeli(){}

    public AdapterAracModeli(Context context,ArrayList<AracModeli> aracModelleri){
        this.context = context;
        this.aracModelleri = aracModelleri;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return aracModelleri.size();
    }

    @Override
    public Object getItem(int position) {
        return aracModelleri.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = layoutInflater.inflate(R.layout.model_satirgoruntusu,null);

        ImageView ivModelResim = view.findViewById(R.id.ivModelResim);
        TextView tvBaslik = view.findViewById(R.id.tvModelBaslik);
        TextView tvIlkUretimYili = view.findViewById(R.id.tvModelIlkUretimYili);
        TextView tvSonUretimYili = view.findViewById(R.id.tvModelSonUretimYili);

        tvBaslik.setText(aracModelleri.get(position).getModelAdi());
        tvIlkUretimYili.setText(""+aracModelleri.get(position).getIlkUretimYili());
        tvSonUretimYili.setText(""+aracModelleri.get(position).getSonUretimYili());

        int resId = view.getResources().getIdentifier(
                aracModelleri.get(position).getModelResim(),
                "drawable",
               context.getPackageName()
        );

        ivModelResim.setImageResource(resId);

        return view;
    }
}
