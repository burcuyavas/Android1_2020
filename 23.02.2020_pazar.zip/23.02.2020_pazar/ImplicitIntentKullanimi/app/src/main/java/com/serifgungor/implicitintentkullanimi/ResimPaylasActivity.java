package com.serifgungor.implicitintentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class ResimPaylasActivity extends AppCompatActivity {

    ImageView ivResim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resim_paylas);
        ivResim = findViewById(R.id.ivResim);

        try{
            ivResim.setImageURI((Uri) getIntent().getExtras().get(Intent.EXTRA_STREAM) );
        }catch(Exception ex){
            Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();
        }

    }
}
