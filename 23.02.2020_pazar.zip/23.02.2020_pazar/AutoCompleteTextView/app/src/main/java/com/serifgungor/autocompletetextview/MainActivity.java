package com.serifgungor.autocompletetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
    MultiAutoCompleteTextView mactv;

    ArrayList<String> sehirler = new ArrayList<>();
    ArrayList<String> dersler = new ArrayList<>();

    public void doldur(){
        sehirler.add("İstanbul");
        sehirler.add("İzmir");
        sehirler.add("İzmit");
        sehirler.add("Ankara");
        sehirler.add("Adıyaman");
        sehirler.add("Adana");
        sehirler.add("Antalya");
        sehirler.add("Çanakkale");
        sehirler.add("Bursa");
        sehirler.add("Edirne");
        sehirler.add("Bolu");
        sehirler.add("Eskişehir");
        sehirler.add("Kütahya");
        sehirler.add("Kocaeli");
        sehirler.add("Konya");

        dersler.add("Android 1");
        dersler.add("Android 2");
        dersler.add("Html5 ve CSS3");
        dersler.add("Html'e giriş");
        dersler.add("Web Programlama");
        dersler.add("Web Programlama (PHP)");
    }


    ArrayAdapter<String> adapterSehirler;
    ArrayAdapter<String> adapterDersler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // this.setTitle("Uygulama Başlığı");
        this.getSupportActionBar().setTitle("Başlık");
        this.getSupportActionBar().setSubtitle("Alt başlık");

        actv = findViewById(R.id.actv);
        mactv = findViewById(R.id.mactv);

        doldur();

        adapterSehirler = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,sehirler);
        adapterDersler = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,dersler);
        actv.setThreshold(3);
        mactv.setThreshold(2);

        actv.setAdapter(adapterSehirler);
        mactv.setAdapter(adapterDersler);
        mactv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());


    }
}
