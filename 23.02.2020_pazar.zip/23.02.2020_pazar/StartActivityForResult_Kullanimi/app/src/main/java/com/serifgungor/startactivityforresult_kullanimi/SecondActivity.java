package com.serifgungor.startactivityforresult_kullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = new Intent();
        intent.putExtra("mesaj","2. sayfaya başarıyla erişildi");
        setResult(1,intent);
        setResult(2,intent);
        setResult(3,intent);



    }
}
