package com.serifgungor.startactivityforresult_kullanimi;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnAy,btnDunya,btnMars;
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAy = findViewById(R.id.btnAy);
        btnDunya = findViewById(R.id.btnDunya);
        btnMars = findViewById(R.id.btnMars);
        tvSonuc = findViewById(R.id.tvSonuc);


        btnAy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(),SecondActivity.class),1);
            }
        });

        btnDunya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(),SecondActivity.class),2);
            }
        });

        btnMars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(),SecondActivity.class),3);
            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){
            tvSonuc.setText("Ay'dan geldim.");
        }else if(requestCode==2){
            tvSonuc.setText("Dünya'dan geldim.");
        }else if(requestCode==3){
            tvSonuc.setText("Mars'dan geldim.");
        }

        if(resultCode==1||resultCode==2||resultCode==3){
            Toast.makeText(getApplicationContext(),data.getStringExtra("mesaj"),Toast.LENGTH_LONG).show();
            /*
            Second activity'de bulunan intentin içerisinde mesaj değişken değerini bir şekilde bir önceki sayfaya taşımam gerekir.
            Mantıken SecondActivity sayfasından MainActivity sayfasını yeni bir sayfa olarak açmamak için, zaten açıl olan
            bir önceki sayfaya değer transferi yapabiliriz.

            Burada data değişkeni, SecondActivity'de üretilmiş olan Intent nesnesini temsil etmektedir. 2. sayfada setResult metodu sayesinde
            intent verisini bir önceki sayfaya iletebiliriz.
             */
        }

    }

    /*
    startActivityForResult, sadece activity sayfasını açmakla yetinmeyip, açılan sayfada bir işlem gerçekleştirildikten sonra
    ilgili sayfanın kapatılıp bir önceki sayfa tekrar aktif hale geldiği esnada, gidilen 2. sayfada işlem sonucunu 1. sayfaya aktarabiliriz.


    onActivityResult metodu uygulamanın geri git butonuna tıklandığı esnada bir önceki sayfada tanımlanmış ve o metoda düşmüş olmasını sağlar.
    Böylelikle gidilen 2. sayfadan geri dönüldüğünde 1. sayfaya veri iletimi yapabiliriz.
     */



}
