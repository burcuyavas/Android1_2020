package com.serifgungor.spinnerkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner spUlkeler;
    String[] ulkeler;
    ArrayAdapter<String> arrayAdapter;
    TextView tvUlke;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spUlkeler = findViewById(R.id.spinner);
        tvUlke = findViewById(R.id.tvUlke);

        ulkeler = getResources().getStringArray(R.array.ulkeler);
        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,ulkeler);
                /*
                simple_spinner_item
                simple_spinner_dropdown_item
                simple_dropdown_item_1line
                 */

        spUlkeler.setAdapter(arrayAdapter);

        spUlkeler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!"-".equals(ulkeler[position])){
                    tvUlke.setText(ulkeler[position]);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        /*
        spUlkeler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        */



    }
}
