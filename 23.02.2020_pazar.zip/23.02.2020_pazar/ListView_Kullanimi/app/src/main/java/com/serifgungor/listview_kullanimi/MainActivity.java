package com.serifgungor.listview_kullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewDersler;
    //String[] dersler;
    ArrayList<String> dersler;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewDersler = findViewById(R.id.listViewDersler);

        dersler = new ArrayList<>();
        dersler.add("Android Programlama");
        dersler.add("iOS Programlama");
        dersler.add("Unity ile Oyun Programlama");
        dersler.add("PHP Programlama");
        dersler.add("Python Programlama");
        dersler.add("Swift Programlama");
        dersler.add("Java Programlama");
        dersler.add("C# Programlama");
        dersler.add(".NET Programlama");
        dersler.add("Java EE Programlama");

        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,dersler);
        listViewDersler.setAdapter(arrayAdapter);

        listViewDersler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(getApplicationContext(),dersler.get(position),Toast.LENGTH_LONG).show();

            }
        });


/*
        dersler = new String[10];
        dersler[0] = "Android Programlama";
        dersler[1] = "iOS Programlama";
        dersler[2] = "Unity ile Oyun Programlama";
        dersler[3] = "PHP Programlama";
        dersler[4] = "Python Programlama";
        dersler[5] = "Swift Programlama";
        dersler[6] = "Java Programlama";
        dersler[7] = "C# Programlama";
        dersler[8] = ".NET Programlama";
        dersler[9] = "Java EE Programlama";
        */




    }
}
