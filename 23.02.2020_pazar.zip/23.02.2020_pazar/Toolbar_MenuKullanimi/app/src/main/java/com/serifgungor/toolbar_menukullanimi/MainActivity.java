package com.serifgungor.toolbar_menukullanimi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnSayfa2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Sayfa 1");

        btnSayfa2 = findViewById(R.id.btnSayfa2);
        btnSayfa2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),SecondActivity.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Toolbara menüyü dahil edebilmek için kullanılır.
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /*
        Menu itemlarının tıklama olayını onOptionsItemSelected metodu sayesinde yakalarız
         */

        if(item.getItemId()==R.id.id_ayarlar){
            Toast.makeText(getApplicationContext(),"Ayarlar",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.id_email){
            Toast.makeText(getApplicationContext(),"Email",Toast.LENGTH_LONG).show();
        }else if(item.getItemId()==R.id.id_iletisim){
            Toast.makeText(getApplicationContext(),"İletişim",Toast.LENGTH_LONG).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
