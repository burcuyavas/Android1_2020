package com.serifgungor.toolbar_menukullanimi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Toolbar'a geri git butonunu ekler

        this.setTitle("Sayfa 2");

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /*
        Toolbarda bulunan bir nesnenin seçilme olayını yakalayabilmek için kullanılır.
        Toolbarda geri git butonu ve menu itemlarının tıklama olayı için onOptionsItemSelected
        metodunu kullanırız.
         */

        if(item.getItemId()==android.R.id.home){
            finish(); // Activity sayfasını kapatır.
        }


        return super.onOptionsItemSelected(item);
    }
}
