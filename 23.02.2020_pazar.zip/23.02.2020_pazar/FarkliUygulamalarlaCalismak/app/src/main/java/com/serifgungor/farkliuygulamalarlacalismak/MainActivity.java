package com.serifgungor.farkliuygulamalarlacalismak;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSms,btnArama,btnWeb,btnHarita,btnPlayStore,btnEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSms = findViewById(R.id.btnSms);
        btnArama = findViewById(R.id.btnArama);
        btnWeb = findViewById(R.id.btnWeb);
        btnHarita = findViewById(R.id.btnHarita);
        btnPlayStore = findViewById(R.id.btnPlayStore);
        btnEmail = findViewById(R.id.btnEmail);

        btnEmail.setOnClickListener(this);
        btnPlayStore.setOnClickListener(this);
        btnHarita.setOnClickListener(this);
        btnWeb.setOnClickListener(this);
        btnArama.setOnClickListener(this);
        btnSms.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        /*
        tel:+905362958509
        geo:q=41.00,28.982025
        smsto:+905362958509
         */

        if(v.getId()==R.id.btnSms){
            Uri uri = Uri.parse("smsto:+90212445478");


            Intent intent = new Intent(Intent.ACTION_SENDTO,uri);
            intent.putExtra("sms_body","SMS İçeriği");
            startActivity(intent);


        }else if(v.getId()==R.id.btnArama){

            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.parse("tel:+902124446677");
            intent.setData(uri);
            startActivity(intent);

            /*
            Uri sınıfı, Uri.parse içerisine gönderilen değerlerin hangi tipte olduğuna karar verir.
            intent sınıfının setData metodu ilgili Uri nesnesi beklemektedir.
            Böylelikle Uri ilgili string'in hangi uygulama tarafından açılabileceğini tespit edip, intente haber eder.

             */


        }else if(v.getId()==R.id.btnWeb){

            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.parse("http://serifgungor.com");
            intent.setData(uri);
            startActivity(intent);


        }else  if(v.getId()==R.id.btnEmail){

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/html");
            intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"contact@serifgungor.com","serif.gungor@ismek.ist"});
            intent.putExtra(Intent.EXTRA_SUBJECT,"Mailin Konusu");
            intent.putExtra(Intent.EXTRA_TEXT,"Mailin içeriği");
            startActivity(Intent.createChooser(intent,"E-posta gönder"));

        }else if(v.getId()==R.id.btnHarita){

            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=41.0168791,28.9409478")));


        }else if(v.getId()==R.id.btnPlayStore){


            try{
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("market://details?id=com.whatsapp");
                intent.setData(uri);
                startActivity(intent);
            }catch (ActivityNotFoundException e){
                Toast.makeText(getApplicationContext(),"Cihazınızda Google Play yüklü değil",Toast.LENGTH_LONG).show();
            }



        }

    }
}
