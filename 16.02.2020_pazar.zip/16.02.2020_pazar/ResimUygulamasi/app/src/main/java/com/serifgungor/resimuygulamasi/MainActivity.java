package com.serifgungor.resimuygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {


    ImageView ivResim;
    ArrayList<String> resimler = new ArrayList<>();
    int index = 0;
    Random random  = new Random();



    public void listeyiDoldur(){
        resimler.add("https://images.unsplash.com/photo-1542282088-fe8426682b8f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80");
        resimler.add("https://images.unsplash.com/photo-1504215680853-026ed2a45def?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80");
        resimler.add("https://images.unsplash.com/photo-1532974297617-c0f05fe48bff?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=700&q=80");
        resimler.add("https://images.unsplash.com/photo-1514316454349-750a7fd3da3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80");
        resimler.add("https://images.unsplash.com/photo-1547570456-0e4070952418?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80");
    }




    public void butonaTikla(View view){

        if(view.getId()==R.id.btnRastgele){

            index = random.nextInt(resimler.size());
            Glide
                    .with(getApplicationContext())
                    .load(resimler.get(index))
                    .into(ivResim);



        }else if(view.getId()==R.id.btnIleri){

           if(index<resimler.size()-1){
               index += 1;
               Glide.with(getApplicationContext()).load(resimler.get(index)).into(ivResim);
           }

        }else if(view.getId()==R.id.btnGeri){

            if(index==0){
                index = 0;
            }else{
                index -= 1;
            }

            Glide.with(getApplicationContext()).load(resimler.get(index)) .into(ivResim);

        }else if(view.getId()==R.id.btnArkaplaniDegistir){

            WallpaperManager wallpaperManager = WallpaperManager.getInstance(getApplicationContext());
            Bitmap bitmap = ((BitmapDrawable)ivResim.getDrawable()).getBitmap();
            try {
                wallpaperManager.setBitmap(bitmap);
                Toast.makeText(getApplicationContext(),"Arkaplan resmi değiştirildi",Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivResim = findViewById(R.id.ivResim);

        listeyiDoldur();
        Glide.with(getApplicationContext()).load(resimler.get(index)).into(ivResim);


    }

}


