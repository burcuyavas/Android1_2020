package com.serifgungor.programatiknesneekleme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onClick(View v) {
        String butonAdi = ((Button)v).getText().toString();
        Toast.makeText(getApplicationContext(),butonAdi,Toast.LENGTH_LONG).show();

    }

    public void nesneUret(String nesneTuru,String nesneAdi){

        View nesne = null;

        if("Button".equals(nesneTuru)){
            nesne = new Button(getApplicationContext());
            ((Button)nesne).setText(nesneAdi);
            ((Button)nesne).setOnClickListener(this);
        }else if("TextView".equals(nesneTuru)){
            nesne = new TextView(getApplicationContext());
            ((TextView)nesne).setText(nesneAdi);
        }else if("CheckBox".equals(nesneTuru)){
            nesne = new CheckBox(getApplicationContext());
            ((CheckBox)nesne).setText(nesneAdi);
        }

        linear.addView(nesne);
    }


    LinearLayout linear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linear = findViewById(R.id.linearLayout);


        for (int i=0; i<20; i++){
            nesneUret("Button","Buton "+i);
        }


        //nesneUret("TextView","YAZI EKLEDİM");
       //nesneUret("CheckBox","Seçenek");



    }

}
