package com.serifgungor.digerbutonolaylari;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    Button btnUzun,btnDokun;
    ToggleButton tb;
    Switch sw;
    CheckBox ch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUzun = findViewById(R.id.btnUzun);
        btnDokun = findViewById(R.id.btnDokun);


        tb = findViewById(R.id.toggleButton);
        sw = findViewById(R.id.switch1);
        ch = findViewById(R.id.checkBox);


        ch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("DENEME","CheckBox Seçildi");
                }else{
                    Log.d("DENEME","CheckBox Seçimi iptal edildi");
                }
            }
        });



        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    Log.d("DENEME","ToggleButton Seçildi");
                }else{
                    Log.d("DENEME","ToggleButton Seçimi iptal edildi");
                }

            }
        });

        tb.setChecked(true);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){
                    Log.d("DENEME","Switch Seçildi");
                }else{
                    Log.d("DENEME","Switch Seçimi iptal edildi");
                }

            }
        });
        sw.setChecked(true);





        btnUzun.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(getApplicationContext(),"Butona uzun basıldı",Toast.LENGTH_LONG).show();
                return false;
            }
        });

        btnDokun.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                Log.d("DENEME","Butona dokunuluyor");


                return false;
            }
        });

    }
}
