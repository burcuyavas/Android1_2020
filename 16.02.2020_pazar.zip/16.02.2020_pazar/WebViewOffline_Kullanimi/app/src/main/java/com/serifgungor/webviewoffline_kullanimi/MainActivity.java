package com.serifgungor.webviewoffline_kullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        //webView.loadUrl("file:///android_asset/index.html");


        StringBuilder sb = new StringBuilder();
        sb.append("<html><head></head><body>");
        sb.append("<style>body{background-color:#bebebe}</style>");
        sb.append("<h1>MERHABA ANDROİD !</h1>");
        sb.append("</body></html>");

        webView.loadData(sb.toString(),"text/html","UTF8");







    }
}
