package com.serifgungor.intent_farklisayfailecalisma;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class ResimActivity extends AppCompatActivity {

    ImageView ivResim;
    String resimAdi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resim);
        ivResim = findViewById(R.id.ivResim);

        resimAdi = getIntent().getStringExtra("resim");

        if("kedi".equals(resimAdi)){
            ivResim.setImageResource(R.drawable.kedi);
        }else if("köpek".equals(resimAdi)){
            ivResim.setImageResource(R.drawable.kopek);
        }else if("kirpi".equals(resimAdi)){
            ivResim.setImageResource(R.drawable.kirpi);
        }


    }
}
