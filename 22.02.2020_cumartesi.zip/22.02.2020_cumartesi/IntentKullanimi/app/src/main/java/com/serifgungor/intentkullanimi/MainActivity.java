package com.serifgungor.intentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etAdSoyad;
    Button btnGonder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAdSoyad =  findViewById(R.id.etAdSoyad);
        btnGonder = findViewById(R.id.btnGonder);



        btnGonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*

               Intent yapısı sayesinde bir sayfadan, farklı bir sayfaya veri taşıyabiliriz.

               Yine intent bir Activity sayfasından farklı bir Activity sayfasına gitmek için de kullanılır.

               Android OS içerisinde bulunan bir uygulama da Intent nesnesi sayesinde açılabilir.
               (Android'în yerli uygulamalarını Intent ile açabiliriz.)
               - Örn: Harita Uygulamasını Aç, Chrome'u aç, Bir kişiyi aramak için rehberi aç, Galeriyi aç, kamerayı aç gibi.

               Androidde paket adını ve sınıf ismini bildiğimiz bir uygulamayı doğrudan açabiliriz.
               Örn: Facebook Uygulamasının LoginActivity sayfasını aç diyebiliriz.

               Intent yapısı sayesinde AndroidManifest.xml içerisinde tanımlanacak olan intent-filterlar
               sayesinde herhangi bir paylaş butonuna tıklandığında paylaşım türüne göre uygulamamıza ait
               bir Activity sayfasını ekranda gösterebiliriz.


                 */


                Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                intent.putExtra("adsoyad",etAdSoyad.getText().toString());
                startActivity(intent); //Activity sayfasını açabilmek için kullanılır.



                /*
                startActivity
                - Sadece Activity sayfasını açar
                startActivityForResult
                - Activity sayfasını açar, geri dönüldüğünde son açtığı sayfadaki elde ettiği verileri
                bir önceki sayfaya tekrar iletebilir.
                 */




            }
        });



    }



}
