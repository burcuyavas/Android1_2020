package com.serifgungor.intentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tvSonuc;

    String adSoyad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvSonuc = findViewById(R.id.tvSonuc);

        adSoyad = getIntent().getStringExtra("adsoyad");

        /*
        Bir önceki sayfadan intent ile gelen verileri yakalayabilmek için getIntent() metodunu kullanabiliriz.
        1. sayfada intent'in put extra metoduna 1. argüman olarak başlık, 2. argüman olarak değer gönderdik.

        Daha sonra gönderdiğimiz değerin değişken türüne göre getIntent().getStringExtra() diyerek adsoyad ismindeki
        başlığa ait sonucu yakalamış olduk. Eğer gönderdiğimiz değer int tipinde olsaydı getIntExtra metodu kullanmamız gerekirdi.

        getIntExtra içerisinde bir başlık birde varsayılan değer ister.

         */

        tvSonuc.setText(adSoyad);

    }
}
