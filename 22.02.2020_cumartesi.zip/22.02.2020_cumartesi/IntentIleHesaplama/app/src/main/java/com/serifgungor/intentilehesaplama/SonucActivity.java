package com.serifgungor.intentilehesaplama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SonucActivity extends AppCompatActivity {

    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonuc);

        tvSonuc = findViewById(R.id.tvSonuc);

        String hesaplamaSonucu = ""+getIntent().getIntExtra("sonuc",0);
        tvSonuc.setText(hesaplamaSonucu);

    }
}
